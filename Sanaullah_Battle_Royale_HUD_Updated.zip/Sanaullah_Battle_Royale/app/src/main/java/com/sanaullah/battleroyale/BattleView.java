package com.sanaullah.battleroyale;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import java.util.*;

public class BattleView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    Random rnd = new Random();
    float W,H, scale=1;
    float px,py, aimX,aimY;
    float joyX,joyY, joyBaseX,joyBaseY;
    boolean joyActive=false, firing=false, started=false, ended=false, won=false;
    int hp=100, armor=50, ammo=30, kills=0;
    long last=System.currentTimeMillis(), fireClock=0;
    float zoneR, zoneTargetR;
    ArrayList<Enemy> enemies = new ArrayList<>();
    ArrayList<Loot> loot = new ArrayList<>();

    class Enemy { float x,y,hp; boolean alive=true; long shot=0;
        Enemy(float x,float y){this.x=x;this.y=y;hp=100;}
    }
    class Loot { float x,y; int type; boolean taken=false;
        Loot(float x,float y,int type){this.x=x;this.y=y;this.type=type;}
    }

    public BattleView(Context c){ super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); setFocusable(true); }

    void reset(){
        W=getWidth(); H=getHeight(); px=W*.5f; py=H*.55f;
        aimX=px+100; aimY=py;
        zoneR=Math.min(W,H)*.46f; zoneTargetR=Math.min(W,H)*.20f;
        hp=100; armor=50; ammo=30; kills=0; ended=false; won=false;
        enemies.clear(); loot.clear();
        for(int i=0;i<10;i++){
            float x=80+rnd.nextFloat()*(W-160), y=100+rnd.nextFloat()*(H-180);
            if(Math.hypot(x-px,y-py)<180){i--;continue;}
            enemies.add(new Enemy(x,y));
        }
        for(int i=0;i<7;i++) loot.add(new Loot(80+rnd.nextFloat()*(W-160),110+rnd.nextFloat()*(H-210),i%2));
        started=true;
        last=System.currentTimeMillis();
        invalidate();
    }

    protected void onDraw(Canvas c){
        W=getWidth(); H=getHeight();
        if(!started){ drawMenu(c); return; }
        long now=System.currentTimeMillis();
        float dt=Math.min(.05f,(now-last)/1000f); last=now;
        update(dt,now);
        drawWorld(c);
        if(ended) drawEnd(c);
        postInvalidateDelayed(16);
    }

    void drawMenu(Canvas c){
        c.drawColor(Color.rgb(12,18,24));
        p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.WHITE); p.setTextSize(42);
        c.drawText("SANAULLAH BATTLE ROYALE",W/2f,H*.32f,p);
        p.setTextSize(18); p.setColor(Color.LTGRAY);
        c.drawText("Original mobile battle-royale prototype",W/2f,H*.39f,p);
        p.setColor(Color.rgb(25,170,90)); c.drawRoundRect(W*.37f,H*.53f,W*.63f,H*.68f,22,22,p);
        p.setColor(Color.WHITE); p.setTextSize(25); c.drawText("START MATCH",W/2f,H*.625f,p);
        p.setTextSize(14); p.setColor(Color.GRAY); c.drawText("Move • Aim • Fire • Loot • Survive",W/2f,H*.76f,p);
    }

    void update(float dt,long now){
        float speed=230;
        if(joyActive){
            px += joyX*speed*dt; py += joyY*speed*dt;
        }
        px=Math.max(25,Math.min(W-25,px)); py=Math.max(70,Math.min(H-25,py));
        zoneR=Math.max(zoneTargetR,zoneR-dt*3.0f);

        // Zone damage
        if(Math.hypot(px-W/2f,py-H/2f)>zoneR){
            if(armor>0) armor=Math.max(0,armor-(int)(dt*9));
            else hp=Math.max(0,hp-(int)(dt*9));
        }

        // Enemies approach and attack
        for(Enemy e:enemies) if(e.alive){
            float dx=px-e.x,dy=py-e.y,d=(float)Math.hypot(dx,dy);
            if(d>55){ e.x+=dx/d*45*dt; e.y+=dy/d*45*dt; }
            if(d<430 && now-e.shot>850){
                e.shot=now;
                if(armor>0) armor=Math.max(0,armor-4); else hp-=6;
            }
        }

        // Firing toward aim point
        if(firing && ammo>0 && now-fireClock>180){
            fireClock=now; ammo--;
            Enemy hit=null; float best=55;
            float vx=aimX-px, vy=aimY-py, len=(float)Math.hypot(vx,vy);
            if(len>1){vx/=len;vy/=len;}
            for(Enemy e:enemies) if(e.alive){
                float ex=e.x-px,ey=e.y-py;
                float proj=ex*vx+ey*vy;
                if(proj>0){
                    float side=Math.abs(ex*vy-ey*vx);
                    if(side<best && proj<900){best=side;hit=e;}
                }
            }
            if(hit!=null){hit.hp-=50; if(hit.hp<=0){hit.alive=false;kills++;}}
        }

        // Auto-pick loot
        for(Loot l:loot) if(!l.taken && Math.hypot(px-l.x,py-l.y)<42){
            l.taken=true;
            if(l.type==0) ammo=Math.min(90,ammo+25); else hp=Math.min(100,hp+25);
        }

        if(hp<=0){hp=0;ended=true;won=false;}
        int alive=0; for(Enemy e:enemies) if(e.alive) alive++;
        if(alive==0){ended=true;won=true;}
    }

    void drawWorld(Canvas c){
        // ground
        c.drawColor(Color.rgb(38,72,48));
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(48,88,57));
        for(int i=0;i<25;i++){
            float x=(i*137)%Math.max(1,(int)W), y=85+(i*83)%Math.max(1,(int)(H-100));
            c.drawCircle(x,y,18+(i%3)*8,p);
        }

        // roads / cover
        p.setColor(Color.rgb(96,91,68)); c.drawRect(0,H*.47f,W,H*.53f,p);
        c.drawRect(W*.46f,70,W*.54f,H,p);

        // zone
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(6); p.setColor(Color.argb(190,80,190,255));
        c.drawCircle(W/2,H/2,zoneR,p); p.setStyle(Paint.Style.FILL);

        // loot
        for(Loot l:loot) if(!l.taken){
            p.setColor(l.type==0?Color.YELLOW:Color.RED); c.drawRect(l.x-10,l.y-10,l.x+10,l.y+10,p);
            p.setColor(Color.WHITE);p.setTextSize(11);p.setTextAlign(Paint.Align.CENTER);
            c.drawText(l.type==0?"AMMO":"MED",l.x,l.y-15,p);
        }

        // enemies
        for(Enemy e:enemies) if(e.alive){
            p.setColor(Color.rgb(190,55,55)); c.drawCircle(e.x,e.y,19,p);
            p.setColor(Color.DKGRAY); c.drawRect(e.x-18,e.y-28,e.x+18,e.y-23,p);
            p.setColor(Color.GREEN); c.drawRect(e.x-18,e.y-28,e.x-18+36*(e.hp/100f),e.y-23,p);
        }

        // aim line
        p.setColor(Color.argb(130,255,255,255));p.setStrokeWidth(2);c.drawLine(px,py,aimX,aimY,p);
        // player
        p.setColor(Color.rgb(45,145,235)); c.drawCircle(px,py,23,p);
        p.setColor(Color.WHITE); c.drawCircle(px,py,8,p);

        drawHUD(c);
        drawControls(c);
    }

    void drawHUD(Canvas c){
        p.setStyle(Paint.Style.FILL);

        // Top-left player status card
        p.setColor(Color.argb(185,0,0,0));
        c.drawRoundRect(15,12,315,82,16,16,p);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(16); p.setColor(Color.WHITE);
        c.drawText("PLAYER",28,32,p);
        c.drawText("HP",28,54,p);
        c.drawText("ARMOR",28,74,p);

        p.setColor(Color.DKGRAY); c.drawRoundRect(78,43,285,56,7,7,p);
        p.setColor(Color.RED); c.drawRoundRect(78,43,78+207*(hp/100f),56,7,7,p);
        p.setColor(Color.DKGRAY); c.drawRoundRect(78,63,285,76,7,7,p);
        p.setColor(Color.CYAN); c.drawRoundRect(78,63,78+207*(armor/50f),76,7,7,p);

        // Alive / kills
        int alive=0; for(Enemy e:enemies) if(e.alive) alive++;
        p.setTextAlign(Paint.Align.RIGHT);
        p.setTextSize(17); p.setColor(Color.WHITE);
        c.drawText("☠  KILLS  "+kills,W-20,32,p);
        c.drawText("👤  ALIVE  "+(alive+1),W-20,56,p);

        // Compass
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(14);
        p.setColor(Color.argb(175,0,0,0));
        c.drawRoundRect(W*.38f,12,W*.62f,46,12,12,p);
        p.setColor(Color.WHITE);
        c.drawText("W     NW     N     NE     E",W/2f,34,p);

        // Mini-map
        float mx=W-112,my=108;
        p.setColor(Color.argb(190,0,0,0)); c.drawCircle(mx,my,72,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
        p.setColor(Color.argb(210,100,210,255)); c.drawCircle(mx,my,58,p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(40,170,255)); c.drawCircle(mx,my,6,p);
        p.setColor(Color.RED);
        for(Enemy e:enemies) if(e.alive){
            float dx=(e.x-W/2f)/Math.max(1,zoneR)*45;
            float dy=(e.y-H/2f)/Math.max(1,zoneR)*45;
            dx=Math.max(-50,Math.min(50,dx)); dy=Math.max(-50,Math.min(50,dy));
            c.drawCircle(mx+dx,my+dy,4,p);
        }
        p.setColor(Color.WHITE);p.setTextSize(11);c.drawText("MAP",mx,my+88,p);

        // Weapon / ammo panel
        p.setColor(Color.argb(190,0,0,0));
        c.drawRoundRect(W-285,H-92,W-18,H-18,16,16,p);
        p.setTextAlign(Paint.Align.LEFT); p.setTextSize(14); p.setColor(Color.LTGRAY);
        c.drawText("ASSAULT RIFLE",W-265,H-64,p);
        p.setTextSize(27); p.setColor(Color.WHITE);
        c.drawText(""+ammo,W-265,H-34,p);
        p.setTextSize(12); p.setColor(Color.LTGRAY);
        c.drawText("/ 90",W-215,H-34,p);

        // Zone warning
        float d=(float)Math.hypot(px-W/2f,py-H/2f);
        if(d>zoneR){
            p.setColor(Color.argb(210,180,25,25));
            c.drawRoundRect(W*.36f,H*.075f,W*.64f,H*.125f,12,12,p);
            p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(14);
            c.drawText("⚠ OUTSIDE SAFE ZONE",W/2f,H*.108f,p);
        } else {
            p.setColor(Color.argb(155,0,0,0));
            c.drawRoundRect(W*.42f,H*.075f,W*.58f,H*.125f,12,12,p);
            p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(12);
            c.drawText("SAFE ZONE",W/2f,H*.108f,p);
        }

        // Crosshair
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
        p.setColor(Color.argb(210,255,255,255));
        c.drawCircle(aimX,aimY,13,p);
        c.drawLine(aimX-22,aimY,aimX-7,aimY,p);
        c.drawLine(aimX+7,aimY,aimX+22,aimY,p);
        c.drawLine(aimX,aimY-22,aimX,aimY-7,p);
        c.drawLine(aimX,aimY+7,aimX,aimY+22,p);
        p.setStyle(Paint.Style.FILL);
    }

    void drawControls(Canvas c){
        // Movement joystick
        p.setColor(Color.argb(70,255,255,255));
        c.drawCircle(105,H-105,78,p);
        p.setColor(Color.argb(145,255,255,255));
        float jx=105+(joyActive?joyX*42:0), jy=H-105+(joyActive?joyY*42:0);
        c.drawCircle(jx,jy,38,p);
        p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(11);
        c.drawText("MOVE",105,H-101,p);

        // Fire button
        p.setColor(firing?Color.rgb(255,70,45):Color.argb(205,195,55,45));
        c.drawCircle(W-105,H-105,66,p);
        p.setColor(Color.WHITE);p.setTextSize(18);
        c.drawText("FIRE",W-105,H-99,p);

        // Aim button / area hint
        p.setColor(Color.argb(150,0,0,0));
        c.drawRoundRect(W-290,18,W-130,52,11,11,p);
        p.setColor(Color.WHITE);p.setTextSize(12);
        c.drawText("AIM / SHOOT",W-210,40,p);

        // Small crouch/jump style buttons (visual controls)
        p.setColor(Color.argb(125,0,0,0));
        c.drawCircle(W-205,H-175,28,p);
        c.drawCircle(W-55,H-190,28,p);
        p.setColor(Color.WHITE);p.setTextSize(11);
        c.drawText("C",W-205,H-171,p);
        c.drawText("J",W-55,H-186,p);
    }

    void drawEnd(Canvas c){
        p.setColor(Color.argb(215,0,0,0));c.drawRect(0,0,W,H,p);
        p.setTextAlign(Paint.Align.CENTER);p.setTextSize(40);
        p.setColor(won?Color.rgb(80,220,120):Color.rgb(240,80,80));
        c.drawText(won?"BOOYAH!":"ELIMINATED",W/2,H*.38f,p);
        p.setColor(Color.WHITE);p.setTextSize(18);
        c.drawText("Kills: "+kills,W/2,H*.46f,p);
        p.setColor(Color.rgb(35,155,85));c.drawRoundRect(W*.39f,H*.55f,W*.61f,H*.68f,18,18,p);
        p.setColor(Color.WHITE);p.setTextSize(22);c.drawText("PLAY AGAIN",W/2,H*.635f,p);
    }

    public boolean onTouchEvent(android.view.MotionEvent e){
        float x=e.getX(), y=e.getY();
        if(!started){
            if(e.getAction()==MotionEvent.ACTION_UP && x>W*.35f&&x<W*.65f&&y>H*.48f&&y<H*.72f) reset();
            return true;
        }
        if(ended){
            if(e.getAction()==MotionEvent.ACTION_UP && x>W*.35f&&x<W*.65f&&y>H*.50f&&y<H*.73f) reset();
            return true;
        }
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                if(x<W*.40f){
                    joyActive=true; joyBaseX=105;joyBaseY=H-105;
                    float dx=x-joyBaseX,dy=y-joyBaseY,len=(float)Math.hypot(dx,dy);
                    if(len>55){dx=dx/len*55;dy=dy/len*55;}
                    joyX=dx/55;joyY=dy/55;
                } else if(x>W*.72f){
                    firing=true;
                    aimX=x;aimY=y;
                } else {
                    aimX=x;aimY=y;
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                joyActive=false;joyX=joyY=0;firing=false;
                break;
        }
        return true;
    }
}
