SANAULLAH BATTLE ROYALE

Yeh ek original Free-Fire-style (inspired) mobile battle-royale prototype hai.
Free Fire ka naam, logo, characters ya copyrighted assets is project mein use nahi kiye gaye.

FEATURES:
- Full-screen landscape Android game
- Touch joystick
- Aim + Fire controls
- 10 enemy bots
- HP + Armor
- Ammo + shooting
- Medkit / ammo loot
- Shrinking safe zone
- Kill counter
- Win / eliminated screen
- Play Again

BUILD:
1. Android Studio install karo.
2. Is project folder ko Android Studio mein Open karo.
3. Gradle sync hone do.
4. Build > Build APK(s) karo.
5. APK ko phone mein install karo.

NOTE:
Is environment mein Android SDK/Gradle compiler available nahi tha, isliye main compiled APK attach nahi kar saka.
Project source complete hai aur Android Studio ke standard Android Gradle Plugin ke liye configured hai.

HUD UPDATE:
- Improved top status HUD
- Compass
- Mini-map with enemy indicators
- Weapon/ammo panel
- Crosshair
- Safe-zone warning
- More polished mobile controls
